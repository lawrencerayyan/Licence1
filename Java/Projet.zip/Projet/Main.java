public class Main {
    public static void main(String[] args) {
        // perso p = new perso();
        // p.tour();
        personnes2 p2 = new personnes2();
        p2.tour();
        // CPU p3 = new CPU();
        // p3.tour();
        

    }
}
