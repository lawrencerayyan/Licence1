package CC;

public class main {
    public static void main(String[] args) {
        puissance p = new puissance();
        p.tour();
    }
}
